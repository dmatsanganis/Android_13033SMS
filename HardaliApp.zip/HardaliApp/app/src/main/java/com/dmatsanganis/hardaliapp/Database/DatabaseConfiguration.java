package com.dmatsanganis.hardaliapp.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import com.dmatsanganis.hardaliapp.R;

public class DatabaseConfiguration extends SQLiteOpenHelper {

    // Initialize SQLite Database.
    private static final String DB_NAME ="MessageReasonsDB";
    public static final String TABLE_NAME ="Messages";
    private static final int DATABASE_VERSION = 1;
    private static final String ID = "reason_id";
    private static final String DATA = "reason_data";
    private static final String TITLE = "reason_title";
    private SQLiteDatabase db;
    private String[] reasonIDArray, reasonDataArray, reasonTitleArray;

    public DatabaseConfiguration(@Nullable Context context)
    {
        super(context, DB_NAME, null  , DATABASE_VERSION);
        this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+TABLE_NAME+ "("+ID+","+DATA+","+TITLE+");");
        db.execSQL("insert into messages values ('"+1+"','"+R.string.summary_request_no1+"','"+R.string.title_request_no1+"')");
        db.execSQL("insert into messages values ('"+2+"','"+R.string.summary_request_no2+"','"+R.string.title_request_no2+"')");
        db.execSQL("insert into messages values ('"+3+"','"+R.string.summary_request_no3+"','"+R.string.title_request_no3+"')");
        db.execSQL("insert into messages values ('"+4+"','"+R.string.summary_request_no4+"','"+R.string.title_request_no4+"')");
        db.execSQL("insert into messages values ('"+5+"','"+R.string.summary_request_no5+"','"+R.string.title_request_no5+"')");
        db.execSQL("insert into messages values ('"+6+"','"+R.string.summary_request_no6+"','"+R.string.title_request_no6+"')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public Cursor getData() {
        db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from Messages",null);
        int count=cursor.getCount();
        cursor.moveToFirst();
        reasonIDArray = new String[count];
        reasonDataArray = new String[count];
        reasonTitleArray = new String[count];
        int i = 0;

        while(cursor.moveToNext()){

            String reason_id = cursor.getString(cursor.getColumnIndex("reason_id"));
            reasonIDArray [i] = reason_id;
            String reason_data = cursor.getString(cursor.getColumnIndex("reason_data"));
            reasonDataArray [i] = reason_data;
            String reason_title = cursor.getString(cursor.getColumnIndex("reason_titles"));
            reasonTitleArray [i] = reason_title;
            i++;

        }
        db.close();
        return cursor;
    }

    public String[] getReasonDataArray() {
        return reasonDataArray;
    }

    public String[] getReasonIDArray() {
        return reasonIDArray;
    }

    public String[] getReasonTitleArray() {
        return reasonTitleArray;
    }
}
