package com.dmatsanganis.hardaliapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.dmatsanganis.hardaliapp.Database.DatabaseConfiguration;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MySpeechRecognizer speechRecognizer;
    private FirebaseAuth mAuth;
    EditText emailtxt, passtxt;
    FirebaseUser currentUser;
    FirebaseDatabase database;
    DatabaseReference ref;
    //DatabaseConfiguration dbHandler = new DatabaseConfiguration(this, null, null, 1);
    private FloatingActionButton speechRecognitionButton;
    private static final int REC_RESULT = 489;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailtxt = findViewById(R.id.textInputEmail);
        passtxt = findViewById(R.id.textInputPassword);
        speechRecognitionButton = findViewById(R.id.mic_main);
        speechRecognizer = new MySpeechRecognizer(this);


        mAuth = FirebaseAuth.getInstance();
        // Check if user is signed in (non-null).
        FirebaseUser currentUser = mAuth.getCurrentUser();

        // Lambda Expression FAB listener (Microphone/TextToSpeech Tool).
        speechRecognitionButton.setOnClickListener((view) -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            {
                // Mic's Permission Check.
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 878);
            }
            else {

                // If permission is already given continue, with the initialization
                //  of the Speech Recognizer function, initSpeechRecognizer().
                initSpeechRecognizer();
            }
        });

    }

    public void signin(View view){
        mAuth.signInWithEmailAndPassword(
                emailtxt.getText().toString(),
                passtxt.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful())
                        {
                            currentUser = mAuth.getCurrentUser();
                           // textView1.setText(currentUser.getUid());
                            Toast.makeText(getApplicationContext(),"Login success!",Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(getApplicationContext(),SendSMS.class);
                            intent.putExtra("fullname",currentUser.getDisplayName());
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),
                                    task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void gotoregister(View view){
        Intent intent = new Intent(getApplicationContext(),Register.class);
        startActivity(intent);
    }

    // Reset password void.
    public void resetpassword(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        view = inflater.inflate(R.layout.reset_password, null);
        EditText submitEmail = view.findViewById(R.id.changepassword_email);
        builder.setCancelable(true)
                .setIcon(R.drawable.hardaliapp_logo)
                .setTitle("Επαναφορά Κωδικόυ Πρόσβασης")
                .setMessage("Συμπληρώστε το e-mail σας, ώστε να μπορέσετε να επαναφέρετε τον κωδικό σας")
                .setView(view)
                .setNegativeButton("Ακύρωση", (dialogInterface, i) -> dialogInterface.cancel())
                .setPositiveButton("Αποστολή Email", (dialog, whichButton) -> {
                    mAuth.sendPasswordResetEmail(submitEmail.getText().toString())
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful())
                                {
                                    Toast.makeText(this, "Ο κωδικός σας έχει σταλθεί στο E-mail!", Toast.LENGTH_LONG).show();
                                    // Debug Console's Message.
                                    Log.d("Password Reset", "Email sent.");
                                }
                                else {
                                    Toast.makeText(this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    // Debug Console's Message.
                                    Log.d("Password Reset", "Error during password reset email");
                                }
                            });
                })
                .show();
    }

    // Check activity results for Speech Recognition and Mic's Events.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REC_RESULT && resultCode == RESULT_OK)
        {
            // Results' Array.
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

            if ((matches.contains("start") || matches.contains("εκκίνηση")) && isClicked)
            {
                startButton.performClick();
            }
            else if ((matches.contains("stop") || matches.contains("pause") || matches.contains("παύση") || matches.contains("σταμάτα")) && (!isClicked))
            {
                // When rec's result matches the
                startButton.performClick();
            }
            else if (matches.contains("violations") || matches.contains("παραβιάσεις"))
            {
                violationsButton.performClick();
            }
            else if (matches.contains("limit") || matches.contains("όριο"))
            {
                setlimitButton.performClick();
            }
            else if (matches.contains("map") || matches.contains("χάρτης"))
            {
                mapButton.performClick();
            }
            else{
                // Toast Message.
                Toast.makeText(this, "Δεν σας καταλάβαμε! Παρακαλώ προσπαθήστε ξανά", Toast.LENGTH_LONG).show();
                // Assistant's Voice Help.
                speechRecognizer.speak("Δεν σας καταλάβαμε! Παρακαλώ προσπαθήστε ξανά!");
            }
        }
        else {
            // Toast Message.
            Toast.makeText(this, "Δεν σας καταλάβαμε! Παρακαλώ προσπαθήστε ξανά", Toast.LENGTH_LONG).show();
            // Assistant's Voice Help.
            speechRecognizer.speak("Δεν σας καταλάβαμε! Παρακαλώ προσπαθήστε ξανά!");
        }
    }

    // Speech Recognizer Void.
    public void initSpeechRecognizer()
    {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Παρακαλω πείτε κάτι!");
        startActivityForResult(intent,REC_RESULT);
    }
}